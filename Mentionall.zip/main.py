from telethon import TelegramClient, events

api_id = 26899070
api_hash = "5299cfcdeaf7e3239c34f3678c7ed882"
bot_token = "8593315446:AAEKFViXvpWSSo1GF3bVr_LJSlPZazBWbDo"

client = TelegramClient("bot", api_id, api_hash).start(bot_token=bot_token)

@client.on(events.NewMessage(pattern="/all"))
async def mention_all(event):
    if not event.is_group:
        await event.reply("❌ الأمر يعمل فقط داخل المجموعات")
        return

    text = ""
    async for user in client.iter_participants(event.chat_id):
        if user.bot:
            continue

        name = user.first_name or "User"
        text += f"[{name}](tg://user?id={user.id}) "

        if len(text) > 3500:
            await event.reply(text, link_preview=False)
            text = ""

    if text:
        await event.reply(text, link_preview=False)

print("✅ Bot is running")
client.run_until_disconnected()