from telethon import TelegramClient, events

api_id = int("API_ID")
api_hash = "API_HASH"
bot_token = "BOT_TOKEN"

client = TelegramClient('bot', api_id, api_hash).start(bot_token=bot_token)

@client.on(events.NewMessage(pattern='/all'))
async def mention_all(event):
    if not event.is_group:
        return await event.reply("يعمل فقط داخل المجموعات")

    text = ""
    async for user in client.iter_participants(event.chat_id):
        if user.bot:
            continue
        text += f"[{user.first_name}](tg://user?id={user.id}) "
        if len(text) > 3500:
            await event.reply(text)
            text = ""

    if text:
        await event.reply(text)

client.run_until_disconnected()